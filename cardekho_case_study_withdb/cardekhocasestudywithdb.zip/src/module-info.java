/**
 * 
 */
/**
 * @author nikhi
 *
 */
module cardekho_case_study_withdb {
	requires java.sql;
}